package com.alcancia.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {
  private WebView web;

  @Override
  protected void onCreate(Bundle state) {
    super.onCreate(state);
    getWindow().setStatusBarColor(Color.parseColor("#0F0F0D"));
    getWindow().setNavigationBarColor(Color.parseColor("#12120F"));

    final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
        .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
        .build();

    web = new WebView(this);
    web.setBackgroundColor(Color.parseColor("#0F0F0D"));
    WebSettings s = web.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(false);
    s.setAllowContentAccess(false);
    web.setWebViewClient(new WebViewClient() {
      @Override
      public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
        return loader.shouldInterceptRequest(request.getUrl());
      }
    });
    setContentView(web);
    web.loadUrl("https://appassets.androidplatform.net/assets/index.html");
  }

  @Override
  public void onBackPressed() {
    // Si hay un formulario abierto lo cierra; si no, sale de la app.
    web.evaluateJavascript(
        "(function(){var s=document.getElementById('sheet');if(s&&!s.hidden){document.getElementById('ov').click();return 1}return 0})()",
        value -> { if (!"1".equals(value)) finish(); });
  }

  @Override
  protected void onPause() { super.onPause(); web.onPause(); }

  @Override
  protected void onResume() { super.onResume(); web.onResume(); }
}
